﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Threading.Tasks;

namespace POE_GUI
{
    public partial class MainWindow : Window
    {
        private ChatBot_AI chatbot;
        private string currentTopic;

        public MainWindow()
        {
            InitializeComponent();
            chatbot = new ChatBot_AI(this);
        }

        // Handle user info submission
        private void SubmitUserInfoButton_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string interest = InterestTextBox.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(name))
            {
                ConversationTextBlock.Text += "==================================================\n";
                ConversationTextBlock.Text += "Please enter a valid name.\n";
                ConversationTextBlock.Text += "==================================================\n";
                return;
            }

            chatbot.SetUserInfo(name, interest);
            UserInfoPanel.Visibility = Visibility.Collapsed;
            MainMenuPanel.Visibility = Visibility.Visible;
            MenuGreetingTextBlock.Text = $"Hi {name}! How can I help with cybersecurity today?";
            currentTopic = interest;
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += $"User entered name: {name}\n";
            if (!string.IsNullOrWhiteSpace(interest))
                ConversationTextBlock.Text += $"User expressed interest in: {interest}\n";
            ConversationTextBlock.Text += "==================================================\n";
        }

        // Switch to chat interface
        private void AskQuestionsButton_Click(object sender, RoutedEventArgs e)
        {
            MainMenuPanel.Visibility = Visibility.Collapsed;
            ChatPanel.Visibility = Visibility.Visible;
            CurrentTopicTextBlock.Text = $"Current topic: {(string.IsNullOrEmpty(currentTopic) ? "None" : currentTopic)}";
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += "Ask a question or choose an option:\n";
            ConversationTextBlock.Text += "==================================================\n";
        }

        // Check mood
        private void CheckMoodButton_Click(object sender, RoutedEventArgs e)
        {
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += $"Your mood score: {chatbot.GetMoodScore()} (Range: -3 to 3)\n";
            ConversationTextBlock.Text += "==================================================\n";
            chatbot.AddToHistory($"User checked mood score: {chatbot.GetMoodScore()}");
        }

        // View memory
        private void ViewMemoryButton_Click(object sender, RoutedEventArgs e)
        {
            var memory = chatbot.GetMemory();
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += "Here's what I remember:\n";
            if (memory.Count == 0)
                ConversationTextBlock.Text += "I don't remember anything about you yet.\n";
            else
                foreach (var item in memory)
                    ConversationTextBlock.Text += $"{item.Key}: {item.Value}\n";
            ConversationTextBlock.Text += "==================================================\n";
            chatbot.AddToHistory("User viewed memory");
        }

        // View history
        private void ViewHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            var history = chatbot.GetHistory();
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += "CHAT HISTORY\n";
            ConversationTextBlock.Text += "==================================================\n";
            if (history.Count == 0)
                ConversationTextBlock.Text += "No history yet.\n";
            else
                foreach (var entry in history)
                    ConversationTextBlock.Text += $"{entry}\n";
            ConversationTextBlock.Text += "==================================================\n";
            chatbot.AddToHistory("User viewed chat history");
        }

        // Exit the application
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            chatbot.AddToHistory("User exited the chat");
            ConversationTextBlock.Text += "==================================================\n";
            ConversationTextBlock.Text += "Goodbye! Stay safe online.\n";
            ConversationTextBlock.Text += "==================================================\n";
            Close();
        }

        // Handle question submission
        private async void SubmitQuestionButton_Click(object sender, RoutedEventArgs e)
        {
            string input = QuestionTextBox.Text.Trim().ToLower();
            if (string.IsNullOrWhiteSpace(input) && !string.IsNullOrEmpty(currentTopic))
                input = currentTopic;

            if (input == "back" || input == "5")
            {
                chatbot.AddToHistory("User returned to menu");
                ChatPanel.Visibility = Visibility.Collapsed;
                MainMenuPanel.Visibility = Visibility.Visible;
                FollowUpPanel.Visibility = Visibility.Collapsed;
                return;
            }

            chatbot.AddToHistory($"User input in conversation: {input}");
            chatbot.AnalyzeMood(input);

            if (input == "1" || input.Contains("password"))
                currentTopic = "password";
            else if (input == "2" || input.Contains("scam"))
                currentTopic = "scam";
            else if (input == "3" || input.Contains("privacy"))
                currentTopic = "privacy";
            else if (input == "4")
            {
                if (string.IsNullOrEmpty(currentTopic))
                {
                    ConversationTextBlock.Text += "==================================================\n";
                    ConversationTextBlock.Text += "No current topic to continue. Please select a topic first.\n";
                    ConversationTextBlock.Text += "==================================================\n";
                    chatbot.AddToHistory("User tried to continue without a topic");
                    QuestionTextBox.Text = string.Empty;
                    return;
                }
                input = currentTopic;
            }

            if (!string.IsNullOrEmpty(currentTopic))
            {
                ConversationTextBlock.Text += "==================================================\n";
                ConversationTextBlock.Text += $"ChatBot is typing...\n";
                await Task.Delay(new Random().Next(1000, 3000));
                string response = chatbot.GetEmotionalResponse() + chatbot.GetRandomResponse(currentTopic);
                ConversationTextBlock.Text += $"{currentTopic.ToUpper()}\n{response}\n";
                ConversationTextBlock.Text += "==================================================\n";
                chatbot.AddToHistory($"Bot response: {response}");
                FollowUpPanel.Visibility = Visibility.Visible;
            }
            else
            {
                ConversationTextBlock.Text += "==================================================\n";
                ConversationTextBlock.Text += "I didn't understand. Can you rephrase or choose a topic?\n";
                ConversationTextBlock.Text += "==================================================\n";
                chatbot.AddToHistory("Bot didn't understand user input");
            }
            QuestionTextBox.Text = string.Empty;
        }

        // Handle follow-up yes
        private async void FollowUpYesButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(currentTopic))
            {
                ConversationTextBlock.Text += "==================================================\n";
                ConversationTextBlock.Text += "ChatBot is typing...\n";
                await Task.Delay(new Random().Next(1000, 3000));
                string response = chatbot.GetRandomResponse(currentTopic);
                ConversationTextBlock.Text += $"{currentTopic.ToUpper()}\n{response}\n";
                ConversationTextBlock.Text += "==================================================\n";
                chatbot.AddToHistory($"Bot provided additional info: {response}");
            }
            FollowUpPanel.Visibility = Visibility.Visible;
        }

        // Handle follow-up no
        private void FollowUpNoButton_Click(object sender, RoutedEventArgs e)
        {
            FollowUpPanel.Visibility = Visibility.Collapsed;
            chatbot.AddToHistory("User declined follow-up");
        }

        // Return to main menu
        private void BackToMenuButton_Click(object sender, RoutedEventArgs e)
        {
            ChatPanel.Visibility = Visibility.Collapsed;
            MainMenuPanel.Visibility = Visibility.Visible;
            FollowUpPanel.Visibility = Visibility.Collapsed;
            chatbot.AddToHistory("User returned to menu");
        }
    }

    public class ChatBot_AI
    {
        private List<string> replies = new List<string>();
        private HashSet<string> ignoreWords = new HashSet<string>();
        private Dictionary<string, int> moodIndicators = new Dictionary<string, int>();
        private Dictionary<string, string> userMemory = new Dictionary<string, string>();
        private List<string> chatHistory = new List<string>();
        private Random random = new Random();
        private int userMoodScore = 0;
        private Dictionary<string, List<string>> topicResponses = new Dictionary<string, List<string>>();
        private readonly MainWindow _window;

        public ChatBot_AI(MainWindow window)
        {
            _window = window;
            InitializeMoodIndicators();
            InitializeResponses();
            PlayGreetingAudio();
            try
            {
                string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "chatbot_image.jpeg");
                if (!File.Exists(imagePath))
                {
                    _window.LogoImage.Visibility = Visibility.Collapsed;
                    _window.LogoErrorTextBlock.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                _window.ConversationTextBlock.Text += $"Logo Error: {ex.Message}\n";
                _window.LogoImage.Visibility = Visibility.Collapsed;
                _window.LogoErrorTextBlock.Visibility = Visibility.Visible;
            }
        }

        public void SetUserInfo(string name, string interest)
        {
            userMemory["name"] = name;
            if (!string.IsNullOrWhiteSpace(interest))
            {
                userMemory["interest"] = interest;
            }
            AddToHistory($"User entered name: {name}");
            if (!string.IsNullOrWhiteSpace(interest))
                AddToHistory($"User expressed interest in: {interest}");
        }

        private void PlayGreetingAudio()
        {
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");
                if (!File.Exists(path))
                {
                    _window.ConversationTextBlock.Text += $"Audio Error: File not found at {path}\n";
                    return;
                }
                MediaPlayer player = new MediaPlayer();
                player.Open(new Uri(path, UriKind.RelativeOrAbsolute));
                player.Play();
            }
            catch (Exception ex)
            {
                _window.ConversationTextBlock.Text += $"Audio Error: {ex.Message}\n";
            }
        }

        private void InitializeMoodIndicators()
        {
            moodIndicators.Add("great", 2);
            moodIndicators.Add("good", 1);
            moodIndicators.Add("excellent", 2);
            moodIndicators.Add("happy", 2);
            moodIndicators.Add("thanks", 1);
            moodIndicators.Add("thank you", 1);
            moodIndicators.Add("awesome", 2);
            moodIndicators.Add("perfect", 2);
            moodIndicators.Add("bad", -1);
            moodIndicators.Add("angry", -2);
            moodIndicators.Add("mad", -2);
            moodIndicators.Add("frustrated", -1);
            moodIndicators.Add("upset", -1);
            moodIndicators.Add("annoyed", -1);
            moodIndicators.Add("hate", -2);
            moodIndicators.Add("help", -1);
            moodIndicators.Add("worried", -2);
            moodIndicators.Add("scared", -2);
        }

        private void InitializeResponses()
        {
            topicResponses.Add("password", new List<string> {
                "Password Security:\n1. Use passphrases (like 'PurpleTurtleJumped42!')\n2. Never share passwords\n3. Change passwords every 3-6 months",
                "Strong Passwords:\n1. 12+ characters\n2. Mix of character types\n3. Avoid personal info",
                "Password Managers:\n1. Generate/store passwords\n2. Only remember one master password\n3. Autofill securely"
            });

            topicResponses.Add("scam", new List<string> {
                "Phishing Tips:\n1. Watch for poor grammar\n2. Hover over links\n3. Never download unexpected attachments",
                "Common Scams:\n1. Fake tech support\n2. Prize notifications\n3. Romance scams",
                "Protection:\n1. Verify requests directly\n2. Don't trust caller ID\n3. When in doubt, don't respond"
            });

            topicResponses.Add("privacy", new List<string> {
                "Online Privacy:\n1. Use different emails\n2. Be careful on social media\n3. Clear cookies",
                "Device Privacy:\n1. Strong passcodes\n2. Disable location services\n3. Review app permissions",
                "Data Protection:\n1. Encrypt files\n2. Use secure messaging\n3. Be cautious with public Wi-Fi"
            });

            string[] wordsToIgnore = {
                "what", "how", "why", "when", "where", "which", "who", "whose",
                "a", "an", "the", "and", "or", "but", "is", "are", "was", "were",
                "do", "does", "did", "can", "could", "should", "would", "will",
                "shall", "safe", "tell", "me", "about", "explain", "describe",
                "give", "example", "examples", "tips", "advice", "please", "help",
                "understand", "know", "security"
            };

            foreach (var word in wordsToIgnore)
            {
                ignoreWords.Add(word);
            }
        }

        public void AnalyzeMood(string userInput)
        {
            userInput = userInput.ToLower();
            foreach (var indicator in moodIndicators)
            {
                if (userInput.Contains(indicator.Key))
                {
                    userMoodScore += indicator.Value;
                }
            }
            userMoodScore = Math.Max(-3, Math.Min(3, userMoodScore));
        }

        public string GetMoodResponse()
        {
            if (userMoodScore > 1) return "I'm glad you're feeling positive! ";
            if (userMoodScore > 0) return "Good to hear you're doing well! ";
            if (userMoodScore < -1) return "I'm sorry you're feeling this way. Let me try to help. ";
            if (userMoodScore < 0) return "I understand this might be frustrating. ";
            return "";
        }

        public string GetEmotionalResponse()
        {
            if (userMoodScore < -1)
            {
                return random.Next(0, 2) == 0
                    ? "I understand this can be overwhelming. "
                    : "It's completely normal to feel this way about cybersecurity. ";
            }
            return "";
        }

        public string GetRandomResponse(string topic)
        {
            if (topicResponses.ContainsKey(topic) && topicResponses[topic].Count > 0)
            {
                return topicResponses[topic][random.Next(topicResponses[topic].Count)];
            }
            return "I specialize in cybersecurity. Please ask about passwords, scams, or privacy.";
        }

        public void AddToHistory(string entry)
        {
            chatHistory.Add($"{DateTime.Now:HH:mm:ss}: {entry}");
        }

        public List<string> GetHistory()
        {
            return new List<string>(chatHistory);
        }

        public Dictionary<string, string> GetMemory()
        {
            return new Dictionary<string, string>(userMemory);
        }

        public int GetMoodScore()
        {
            return userMoodScore;
        }
    }
}