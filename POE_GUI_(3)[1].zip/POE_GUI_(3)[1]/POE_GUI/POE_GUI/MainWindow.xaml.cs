﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace POE_GUI
{
    public partial class MainWindow : Window
    {
        private ChatBotService chatbot = new ChatBotService();
        private int currentQuizQuestionIndex = -1;

        public MainWindow()
        {
            InitializeComponent();
            InitializeChat();
            RefreshTasks();
            RefreshActivityLog();
        }

        private void InitializeChat()
        {
            tbChatHistory.Text = "Welcome to the Cybersecurity Awareness Chatbot!\n" +
                                "Type your questions about cybersecurity, or use the tabs to:\n" +
                                "- Manage security tasks\n" +
                                "- Test your knowledge with a quiz\n" +
                                "- View your activity log\n\n" +
                                "How can I help you today?";
        }

        #region Chat Tab Events
        private void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            ProcessUserInput();
        }

        private void TbUserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ProcessUserInput();
            }
        }

        private void ProcessUserInput()
        {
            if (!string.IsNullOrWhiteSpace(tbUserInput.Text))
            {
                string userInput = tbUserInput.Text;
                string response = chatbot.ProcessInput(userInput);

                tbChatHistory.AppendText($"\n\nYou: {userInput}\n");
                tbChatHistory.AppendText($"Bot: {response}");

                tbUserInput.Clear();
                tbChatHistory.ScrollToEnd();

                UpdateMoodIndicator();
                RefreshActivityLog();
            }
        }

        private void UpdateMoodIndicator()
        {
            tbMoodIndicator.Text = "User Mood: " + chatbot.GetMoodResponse().Trim();
        }
        #endregion

        #region Task Assistant Tab Events
        private void CbSetReminder_Checked(object sender, RoutedEventArgs e)
        {
            dpReminderDate.IsEnabled = true;
            dpReminderDate.SelectedDate = DateTime.Today.AddDays(1);
        }

        private void CbSetReminder_Unchecked(object sender, RoutedEventArgs e)
        {
            dpReminderDate.IsEnabled = false;
            dpReminderDate.SelectedDate = null;
        }

        private void BtnAddTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbTaskTitle.Text))
            {
                MessageBox.Show("Please enter a task title", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DateTime? reminderDate = cbSetReminder.IsChecked == true ? dpReminderDate.SelectedDate : null;
            chatbot.AddTask(tbTaskTitle.Text, tbTaskDescription.Text, reminderDate);

            tbTaskTitle.Clear();
            tbTaskDescription.Clear();
            cbSetReminder.IsChecked = false;

            RefreshTasks();
            RefreshActivityLog();
        }

        private void TaskCompleteCheckBox_Click(object sender, RoutedEventArgs e)
        {
            var checkBox = (CheckBox)sender;
            var task = (TaskItem)checkBox.DataContext;
            chatbot.CompleteTask(task);
            RefreshActivityLog();
        }

        private void BtnRefreshTasks_Click(object sender, RoutedEventArgs e)
        {
            RefreshTasks();
        }

        private void BtnClearCompleted_Click(object sender, RoutedEventArgs e)
        {
            var tasks = chatbot.GetTasks();
            tasks.RemoveAll(t => t.IsCompleted);
            RefreshTasks();
            RefreshActivityLog();
        }

        private void RefreshTasks()
        {
            lvTasks.ItemsSource = null;
            lvTasks.ItemsSource = chatbot.GetTasks();
        }
        #endregion

        #region Quiz Tab Events
        private void BtnStartQuiz_Click(object sender, RoutedEventArgs e)
        {
            chatbot.ResetQuizScore();
            currentQuizQuestionIndex = 0;
            LoadQuizQuestion(currentQuizQuestionIndex);
            btnStartQuiz.IsEnabled = false;
            tbQuizScore.Text = "0";
            tbQuizFeedback.Text = "";
        }

        private void LoadQuizQuestion(int index)
        {
            if (index >= 0 && index < chatbot.QuizQuestionCount)
            {
                var question = chatbot.GetQuizQuestion(index);
                tbQuizQuestion.Text = question.Question;
                rbOption1.Content = question.Options[0];
                rbOption2.Content = question.Options[1];
                rbOption3.Content = question.Options[2];
                rbOption4.Content = question.Options[3];

                tbQuizProgress.Text = $"{index + 1} of {chatbot.QuizQuestionCount}";

                // Clear selection
                rbOption1.IsChecked = rbOption2.IsChecked = rbOption3.IsChecked = rbOption4.IsChecked = false;

                // Update navigation buttons
                btnPreviousQuestion.IsEnabled = index > 0;
                btnNextQuestion.IsEnabled = index < chatbot.QuizQuestionCount - 1;
            }
        }

        private void BtnSubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuizQuestionIndex == -1) return;

            var question = chatbot.GetQuizQuestion(currentQuizQuestionIndex);
            int selectedIndex = -1;

            if (rbOption1.IsChecked == true) selectedIndex = 0;
            else if (rbOption2.IsChecked == true) selectedIndex = 1;
            else if (rbOption3.IsChecked == true) selectedIndex = 2;
            else if (rbOption4.IsChecked == true) selectedIndex = 3;

            if (selectedIndex == -1)
            {
                MessageBox.Show("Please select an answer", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (selectedIndex == question.CorrectAnswerIndex)
            {
                chatbot.IncrementQuizScore();
                tbQuizScore.Text = chatbot.GetQuizScore().ToString();
                tbQuizFeedback.Text = $"Correct! {question.Explanation}";
            }
            else
            {
                tbQuizFeedback.Text = $"Incorrect. The correct answer was: {question.Options[question.CorrectAnswerIndex]}\n{question.Explanation}";
            }

            btnSubmitAnswer.IsEnabled = false;
        }

        private void BtnPreviousQuestion_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuizQuestionIndex > 0)
            {
                currentQuizQuestionIndex--;
                LoadQuizQuestion(currentQuizQuestionIndex);
                btnSubmitAnswer.IsEnabled = true;
                tbQuizFeedback.Text = "";
            }
        }

        private void BtnNextQuestion_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuizQuestionIndex < chatbot.QuizQuestionCount - 1)
            {
                currentQuizQuestionIndex++;
                LoadQuizQuestion(currentQuizQuestionIndex);
                btnSubmitAnswer.IsEnabled = true;
                tbQuizFeedback.Text = "";
            }
        }

        private void BtnShowResults_Click(object sender, RoutedEventArgs e)
        {
            int score = chatbot.GetQuizScore();
            int total = chatbot.QuizQuestionCount;
            double percentage = (double)score / total * 100;

            string message = $"You scored {score} out of {total} ({percentage:0}%)\n\n";
            if (percentage >= 80) message += "Excellent! You're a cybersecurity expert!";
            else if (percentage >= 60) message += "Good job! You know quite a bit about cybersecurity.";
            else if (percentage >= 40) message += "Not bad! Keep learning to improve your cybersecurity knowledge.";
            else message += "Keep practicing! Cybersecurity is important for everyone.";

            MessageBox.Show(message, "Quiz Results", MessageBoxButton.OK, MessageBoxImage.Information);
            btnStartQuiz.IsEnabled = true;
            currentQuizQuestionIndex = -1;
        }
        #endregion

        #region Activity Log Tab Events
        private void BtnRefreshLog_Click(object sender, RoutedEventArgs e)
        {
            RefreshActivityLog();
        }

        private void BtnClearLog_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to clear the activity log?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                tbActivityLog.Text = "Activity log cleared";
            }
        }

        private void RefreshActivityLog()
        {
            tbActivityLog.Text = chatbot.GetActivityLog();
        }
        #endregion
    }

    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public override string ToString()
        {
            return $"{Title} - {Description} {(ReminderDate.HasValue ? $"(Reminder: {ReminderDate.Value.ToShortDateString()})" : "")}";
        }
    }

    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public string Explanation { get; set; }

        public QuizQuestion()
        {
            Options = new List<string>();
        }
    }

    public class ChatBotService
    {
        // Data structures
        private Dictionary<string, List<string>> topicResponses = new Dictionary<string, List<string>>();
        private Dictionary<string, int> moodIndicators = new Dictionary<string, int>();
        private Dictionary<string, string> userMemory = new Dictionary<string, string>();
        private List<string> activityLog = new List<string>();
        private List<TaskItem> tasks = new List<TaskItem>();
        private List<QuizQuestion> quizQuestions = new List<QuizQuestion>();
        private Random random = new Random();

        // State
        private int userMoodScore = 0;
        private string currentTopic = "";
        private int quizScore = 0;

        public ChatBotService()
        {
            InitializeMoodIndicators();
            InitializeResponses();
            InitializeQuizQuestions();
        }

        private void InitializeMoodIndicators()
        {
            // Positive indicators
            moodIndicators.Add("great", 2);
            moodIndicators.Add("good", 1);
            moodIndicators.Add("excellent", 2);
            moodIndicators.Add("happy", 2);
            moodIndicators.Add("thanks", 1);
            moodIndicators.Add("thank you", 1);
            moodIndicators.Add("awesome", 2);
            moodIndicators.Add("perfect", 2);

            // Negative indicators
            moodIndicators.Add("bad", -1);
            moodIndicators.Add("angry", -2);
            moodIndicators.Add("mad", -2);
            moodIndicators.Add("frustrated", -1);
            moodIndicators.Add("upset", -1);
            moodIndicators.Add("annoyed", -1);
            moodIndicators.Add("hate", -2);
            moodIndicators.Add("help", -1);
            moodIndicators.Add("worried", -2);
            moodIndicators.Add("scared", -2);
        }

        private void InitializeResponses()
        {
            topicResponses.Add("password", new List<string> {
                "Password Security:\n1. Use passphrases (like 'PurpleTurtleJumped42!')\n2. Never share passwords\n3. Change passwords every 3-6 months",
                "Strong Passwords:\n1. 12+ characters\n2. Mix of character types\n3. Avoid personal info",
                "Password Managers:\n1. Generate/store passwords\n2. Only remember one master password\n3. Autofill securely"
            });

            topicResponses.Add("scam", new List<string> {
                "Phishing Tips:\n1. Watch for poor grammar\n2. Hover over links\n3. Never download unexpected attachments",
                "Common Scams:\n1. Fake tech support\n2. Prize notifications\n3. Romance scams",
                "Protection:\n1. Verify requests directly\n2. Don't trust caller ID\n3. When in doubt, don't respond"
            });

            topicResponses.Add("privacy", new List<string> {
                "Online Privacy:\n1. Use different emails\n2. Be careful on social media\n3. Clear cookies",
                "Device Privacy:\n1. Strong passcodes\n2. Disable location services\n3. Review app permissions",
                "Data Protection:\n1. Encrypt files\n2. Use secure messaging\n3. Be cautious with public Wi-Fi"
            });
        }

        private void InitializeQuizQuestions()
        {
            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do if you receive an email asking for your password?",
                Options = new List<string> {
                    "Reply with your password",
                    "Delete the email",
                    "Report the email as phishing",
                    "Ignore it"
                },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Reporting phishing emails helps prevent scams."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "Which of these is the strongest password?",
                Options = new List<string> {
                    "password123",
                    "P@ssw0rd!",
                    "CorrectHorseBatteryStaple",
                    "12345678"
                },
                CorrectAnswerIndex = 2,
                Explanation = "Correct! Long passphrases are more secure than complex but short passwords."
            });

            // Add more questions...
        }

        public void AddToActivityLog(string entry)
        {
            activityLog.Add($"{DateTime.Now:HH:mm:ss}: {entry}");
        }

        public string GetActivityLog()
        {
            return string.Join("\n", activityLog.TakeLast(10).Reverse());
        }

        public void AnalyzeMood(string userInput)
        {
            userInput = userInput.ToLower();
            foreach (var indicator in moodIndicators)
            {
                if (userInput.Contains(indicator.Key))
                {
                    userMoodScore += indicator.Value;
                }
            }
            userMoodScore = Math.Max(-3, Math.Min(3, userMoodScore));
        }

        public string GetMoodResponse()
        {
            if (userMoodScore > 1) return "I'm glad you're feeling positive! ";
            if (userMoodScore > 0) return "Good to hear you're doing well! ";
            if (userMoodScore < -1) return "I'm sorry you're feeling this way. Let me try to help. ";
            if (userMoodScore < 0) return "I understand this might be frustrating. ";
            return "";
        }

        public string GetEmotionalResponse()
        {
            if (userMoodScore < -1)
            {
                return random.Next(0, 2) == 0
                    ? "I understand this can be overwhelming. "
                    : "It's completely normal to feel this way about cybersecurity. ";
            }
            return "";
        }

        public string ProcessInput(string input)
        {
            AddToActivityLog($"User: {input}");
            AnalyzeMood(input);

            // Check for commands
            if (input.ToLower().Contains("add task") || input.ToLower().Contains("set reminder"))
            {
                return "Please use the Task Assistant tab to add tasks or set reminders.";
            }
            else if (input.ToLower().Contains("quiz") || input.ToLower().Contains("game"))
            {
                return "You can test your knowledge in the Cybersecurity Quiz tab!";
            }
            else if (input.ToLower().Contains("activity log") || input.ToLower().Contains("what have you done"))
            {
                return $"Recent Activity:\n{GetActivityLog()}";
            }

            // Topic detection
            if (input.Contains("password"))
            {
                currentTopic = "password";
                userMemory["interest"] = "password security";
            }
            else if (input.Contains("scam"))
            {
                currentTopic = "scam";
                userMemory["interest"] = "scam protection";
            }
            else if (input.Contains("privacy"))
            {
                currentTopic = "privacy";
                userMemory["interest"] = "privacy protection";
            }

            if (!string.IsNullOrEmpty(currentTopic))
            {
                string response = GetEmotionalResponse() + GetRandomResponse(currentTopic);
                AddToActivityLog($"Bot: {response}");
                return response;
            }

            string defaultResponse = "I specialize in cybersecurity. Please ask about passwords, scams, or privacy. " +
                                   "You can also use the tabs to manage tasks or take a quiz!";
            AddToActivityLog($"Bot: {defaultResponse}");
            return defaultResponse;
        }

        private string GetRandomResponse(string topic)
        {
            if (topicResponses.ContainsKey(topic) && topicResponses[topic].Count > 0)
            {
                return topicResponses[topic][random.Next(topicResponses[topic].Count)];
            }
            return "I'm not sure about that topic. Could you ask about passwords, scams, or privacy?";
        }

        // Task management
        public void AddTask(string title, string description, DateTime? reminderDate)
        {
            tasks.Add(new TaskItem
            {
                Title = title,
                Description = description,
                ReminderDate = reminderDate
            });
            AddToActivityLog($"Task added: {title}");
        }

        public List<TaskItem> GetTasks()
        {
            return tasks;
        }

        public void CompleteTask(TaskItem task)
        {
            task.IsCompleted = true;
            AddToActivityLog($"Task completed: {task.Title}");
        }

        // Quiz functionality
        public QuizQuestion GetQuizQuestion(int index)
        {
            if (index >= 0 && index < quizQuestions.Count)
            {
                return quizQuestions[index];
            }
            return null;
        }

        public int QuizQuestionCount => quizQuestions.Count;

        public void IncrementQuizScore()
        {
            quizScore++;
        }

        public int GetQuizScore()
        {
            return quizScore;
        }

        public void ResetQuizScore()
        {
            quizScore = 0;
        }
    }
}